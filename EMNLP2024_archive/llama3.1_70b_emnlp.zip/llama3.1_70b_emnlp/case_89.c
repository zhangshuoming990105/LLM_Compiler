
double light_time(double distance) {
    double t = 0.0;



    return t;
}