
int f6(int c, int shamt) {




  return c << shamt;
}