
char * getTokenTypeName(int type){
 switch(type){
  case 1:
   return "<LParen>";
  case 2:
   return "<RParen>";
  case 3:
   return "<Number>";
  case 8:
   return "<ID>";
  case 6:
   return "<Plus>";
  case 7:
   return "<Minus>";
  case -2:
   return "<EOF>";
  case -1:
   return "<Error!>";
  default:
   return "<Unknown token type!>";
 }
}