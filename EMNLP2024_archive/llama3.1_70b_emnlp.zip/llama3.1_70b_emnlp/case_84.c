#include <stdio.h>

int hcf_iterative(int a, int b){
 int q, r;
 if(a > 0 && b > 0){
  if(a < b)
   return hcf_iterative(b, a);

  q = a / b;
  r = a % b;
  while(r != 0 && r != 1){
   a = b;
   b = r;
   q = a / b;
   r = a % b;
  }

  if(r == 0)
   return b;
  else if(r == 1)
   return 1;
 }
 return -1;
}