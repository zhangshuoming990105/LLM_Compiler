#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <math.h>

#include <time.h>

#include <omp.h>

#include <unistd.h>

int checkExpDesignator(char *str, int len)
{
 int i,n=0;

 for (i=0; i<len; i++)
 {
  if (str[i]=='D')
  {
   n++;
   str[i] = 'E';
  }
 }

 return(n);
}