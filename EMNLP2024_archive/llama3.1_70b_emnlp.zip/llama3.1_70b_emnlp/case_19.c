#include <stdio.h>

#include <time.h>

#include <string.h>

#include <stdlib.h>

#include <assert.h>

char *skipSpaces(char *pc)
{
 while((*pc == ' ' || *pc == '\n' || *pc == '\t' || *pc == '\r') &&
   *pc != '\0')
  pc++;

 return pc;
}