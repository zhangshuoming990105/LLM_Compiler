
char *init_buffer(char *buffer)
{
 int i;

 i = 0;
 while (buffer[i])
  buffer[i++] = 0;
 return (buffer);
}