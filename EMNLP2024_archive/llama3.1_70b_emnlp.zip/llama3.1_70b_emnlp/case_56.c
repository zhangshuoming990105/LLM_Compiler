#include <stdio.h>

int checkrange(char c1, char c2)
{

 if (('a' <= c1 && c1 <= 'z') && (c1 <= c2 && c2 <= 'z'))
  return 1;

 if (('A' <= c1 && c1 <= 'Z') && (c1 <= c2 && c2 <= 'Z'))
  return 1;

 if (('0' <= c1 && c1 <= '9') && (c1 <= c2 && c2 <= '9'))
  return 1;

 return 0;
}