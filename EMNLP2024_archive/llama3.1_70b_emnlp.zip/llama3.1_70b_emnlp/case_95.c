#include <ctype.h>

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <stdint.h>

#include <math.h>

#include <time.h>

#include <fcntl.h>

#include <sys/types.h>

#include <errno.h>

#include <limits.h>

double calc_swst(unsigned short swst_dn, double pri)
{


     return ((double) swst_dn * 210.94e-09 + 9.0 * pri - 6.6E-6);
}