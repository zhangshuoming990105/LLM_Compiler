#include <inttypes.h>

#include <stdlib.h>

#include <limits.h>

#include <stdio.h>

#include <string.h>

#include <sqlite3.h>

int Bank_int_IsValidName(const char *Name)
{
 if( !Name ) return 0;
 while(*Name)
 {
  if( *Name == '\'' ) return 0;
  Name ++;
 }
 return 1;
}