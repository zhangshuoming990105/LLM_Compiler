#include <stdio.h>

int dec_lv(char x, char c, int lv)
{
 if (x == c)
  --lv;

 return lv;
}