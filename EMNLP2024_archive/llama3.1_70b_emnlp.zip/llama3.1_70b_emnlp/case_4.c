#include <stdio.h>

#include <stdlib.h>

#include <memory.h>

int* sub(int* a, int sizeA, int* b, int sizeB, int* resultSize){

}