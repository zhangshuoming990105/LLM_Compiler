#include <stdio.h>

#include <math.h>

#include <stdlib.h>

#include <unistd.h>

#include <stdarg.h>

#include <string.h>

double H (double x) {
   if (x >= 0) return 1.;
   else return 0.;
}