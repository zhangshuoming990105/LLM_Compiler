#include <stdio.h>

#include <string.h>

char cipher (char c){
 if(c >= 65 && c<= 90){
  c = c - 65;
  c = 90 - c;
 }else if( c >= 97 && c<= 122){
  c = c-97;
  c = 122 - c;
 }
 return c;
}