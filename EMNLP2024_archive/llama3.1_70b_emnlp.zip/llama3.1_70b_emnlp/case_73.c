#include <math.h>

float fast_cbrtf(float x)
{
   union {int ix; float x;} v;
   v.x = x;
   v.ix = v.ix/4 + v.ix/16;
   v.ix = v.ix + v.ix/16;
   v.ix = v.ix + v.ix/256;
   v.ix = 0x2a511cd0 + v.ix;
   return v.x;
}