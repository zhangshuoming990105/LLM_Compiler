


















int xtoi(char *p)
{
 int curr;
 int res = 0;

 while (*p)
 {
  curr = ((*p) >= '0' && (*p) <= '9' ? (*p) - '0' : (*p) >= 'A' && (*p) <= 'F' ? (*p) - 'A' + 10 : (*p) >= 'a' && (*p) <= 'f' ? (*p) - 'a' + 10 : -1);
  if (curr == -1) break;
  res = res * 0x10 + curr;
  p++;
 }

 return res;
}