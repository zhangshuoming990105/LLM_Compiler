
int ft_iterative_factorial(int nb)
{
 int i;
 int result;


 result = 1;
 i = 1;
 while (i <= nb)
 {
  result = i * result;
  i++;
 }
 return (result);
}