#include <stdio.h>

#include <stdlib.h>

int text_length(char *text)
{
    int length = 0;
    while (text[length] != '\0') length++;
    return length;
}