
unsigned short int
f61 (unsigned short int x, int y)
{
  return (x << ((-y) & (8 * sizeof (unsigned short) - 1))) ^ (x >> y);
}