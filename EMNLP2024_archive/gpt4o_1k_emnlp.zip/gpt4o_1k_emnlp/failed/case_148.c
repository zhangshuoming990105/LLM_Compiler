#include <stdio.h>

#include <stdlib.h>

int cr_has_byte_in_string(char byte, char *arg) {
  int c;
  c = -1;
  while (0 != c) {
    c = (int)*arg++;
    if ((char)c == byte) {
      return 1;
    }
  }
  return 0;
}