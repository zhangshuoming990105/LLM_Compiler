#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <setjmp.h>

#include <ctype.h>

#include <time.h>

int is_l_end(char c)
{
 return (c == '\0') || (c == ':');
}