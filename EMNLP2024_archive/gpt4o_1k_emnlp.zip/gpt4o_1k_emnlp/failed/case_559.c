
double test12(int c) {
  return c ? 4.0 : 2.0;
}