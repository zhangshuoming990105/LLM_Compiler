
unsigned char func(unsigned char arg0)
{
 return arg0 + 3;
}