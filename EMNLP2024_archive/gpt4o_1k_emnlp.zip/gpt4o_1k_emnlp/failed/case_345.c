
unsigned int get_length_of_text(char *text)
{
    int i = 0;
    while (text[i] != '\0') {
        i++;
    }
    return i;
}