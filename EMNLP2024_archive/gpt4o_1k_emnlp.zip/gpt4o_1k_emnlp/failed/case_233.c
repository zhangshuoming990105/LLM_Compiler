#include <stdio.h>

int separateur(char c) {
  return (c == ' ' || c == '\t' || c == '\n');
}