
int my_get_el(char c, char *base)
{
  int lp;

  lp = 0;
  while (base[lp] != '\0')
    {
      if (c == base[lp])
        return (lp);
      ++lp;
    }
  return (-1);
}