#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <math.h>

#include <time.h>

#include <sys/timeb.h>

float range3f(float v1,float v2,float v3)
{






  float range;
  float max;
  float min;

  if (v1>v2) {
    if (v1>v3) {
      max=v1;
      if (v2>v3) {
 min=v3;
      } else {
 min=v2;
      }
    } else {
      max=v3;
      min=v2;
    }
  } else {
    if (v2>v3) {
      max=v2;
      if (v1>v3) {
 min=v3;
      } else {
 min=v1;
      }
    } else {
      max=v3;
      min=v1;
    }
  }

  range=max-min;

  return range;
}