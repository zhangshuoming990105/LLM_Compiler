#include <stdio.h>

#include <stdlib.h>

int VerifSomaLados (int *dados){
  int bolean=0;
  if(dados[0]+dados[5]!=7)
    bolean=1;
  else if(dados[1]+dados[3]!=7)
    bolean=1;
  else if(dados[2]+dados[4]!=7)
    bolean=1;
  return bolean;
}