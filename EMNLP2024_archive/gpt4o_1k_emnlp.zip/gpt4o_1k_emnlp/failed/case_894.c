#include <stdio.h>

int is_num_in_array(int *p,int array_size,int n)
{
    int i;

    for(i=0; i<array_size; i++)
    {
        if(p[i]==n)
        {
            return 1;
        }
    }
    return -1;
}