
int check_wager_amount (double wager, double balance)
{

 int is_valid = 0;


 if ((wager > 0) && (balance >= wager))
 {
  is_valid = 1;
 }

 return is_valid;
}