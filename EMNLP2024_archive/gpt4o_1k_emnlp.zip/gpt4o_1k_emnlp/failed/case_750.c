#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <math.h>

#include <float.h>

const double resonanceToQ(const double resonance)
{
 return 1.0 / (2.0 * (1.0 - resonance));
}