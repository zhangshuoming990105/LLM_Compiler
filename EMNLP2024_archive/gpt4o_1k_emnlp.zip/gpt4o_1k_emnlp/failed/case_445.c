
int is_in_bound(int *arr,int size,int *ptr)
{
 if(ptr<arr+size)
 {
  return 1;
 }
 else
 {
  return 0;
 }
}