
unsigned short int
f30 (unsigned short int x, unsigned long int y)
{
  return (x >> (8 * sizeof (unsigned short) - y)) ^ (x << y);
}