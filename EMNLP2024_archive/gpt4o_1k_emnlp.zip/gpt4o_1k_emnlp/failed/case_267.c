#include <stdio.h>

#include <string.h>

#include <math.h>

#include <stdlib.h>

int getNextDiff(char s[], int index) {
    int ret = index + 1;

    while (s[ret]) {
        if (s[ret] != s[index]) {
            break;
        }

        ret ++;
    }

    return ret;
}