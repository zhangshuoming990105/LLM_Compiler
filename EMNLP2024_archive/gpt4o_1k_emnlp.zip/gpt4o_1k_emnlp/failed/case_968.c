#include <stdint.h>

#include <assert.h>

char
rust_dbg_extern_identity_u8(char u) {
    return u;
}