#include <stdio.h>

#include <stdlib.h>

int name_t(char * help,char *bb,char *ab,char * fp,char*pb)
{
    int i= 6;
    int b;



    if(help[i]== 57 && help[i+1]== 51&& help[i+2]== 51 && help[i+3]== 51 &&help[i+4]== 52 &&help[i+5]== 54 && help[i+6] == '-')
    {
        return b= 1 ;
    }
    if(help[i]== 53 &&help[i+1]== 53 && help[i+2]== 53 && help[i+3]== 56 && help[i+4] == 51 && help[i+5] == '-')
    {

        return b = 2 ;
    }
    if(help[i]== 52 &&help[i+1]== 50 && help[i+2]== 49 && help[i+3]== 48 && help[i+4] == '-')
    {
        return b = 3 ;
    }
    if(help[i]== 48 &&help[i+1]== 49 && help[i+2] == '-')
    {
        return b = 4;
    }
    return 0;
}