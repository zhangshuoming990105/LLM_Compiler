#include <stdio.h>

#include <stdlib.h>

#include <stdint.h>

#include <inttypes.h>

#include <math.h>

double fpu_fchs(double a)
{
 double b;
 b = -a;




 return b;
}