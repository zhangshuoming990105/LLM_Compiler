#include <stdio.h>

#include <stdlib.h>

int FindMultipleSum(int number)
{
    int sum = 0;


    sum = ((3 + (number / 3) * 3) * (number / 3)) / 2
          + ((5 + (number / 5) * 5) * (number / 5)) / 2
          - ((15 + (number / 15) * 15) * (number / 15)) / 2;

    return sum;
}