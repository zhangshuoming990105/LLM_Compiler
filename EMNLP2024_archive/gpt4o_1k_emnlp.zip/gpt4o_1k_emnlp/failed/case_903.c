
unsigned short int
f45 (unsigned short int x, int y)
{
  return (x >> y) | (x << (8 * sizeof (unsigned short) - y));
}