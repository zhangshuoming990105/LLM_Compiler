































int dns_v_abi(void) {
 return 0x20160608;
}