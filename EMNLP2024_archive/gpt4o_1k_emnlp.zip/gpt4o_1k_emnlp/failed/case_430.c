
unsigned int
f89 (unsigned int x, int y)
{
  return (x << (8 * sizeof (unsigned int) - y)) + (x >> y);
}