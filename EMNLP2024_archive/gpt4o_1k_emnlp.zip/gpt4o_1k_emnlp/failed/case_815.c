#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <ctype.h>

char loCase(const char c)
{
 return ('A' <= c && c <= 'Z') ? c -'A' + 'a' : c;
}