#include <stdio.h>

#include <stdlib.h>

int getPrec(char op) {

    switch(op) {
        case '+':
        case '-':
        return 1;

        case '*':
        case '/':
        return 2;


        case '(':
        case ')':
        return 3;

        default:
        return 0;
    }
}