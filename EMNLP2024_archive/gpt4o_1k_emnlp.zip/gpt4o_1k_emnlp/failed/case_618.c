
unsigned int
f73 (unsigned int x, int y)
{
  return (x << y) + (x >> (8 * sizeof (unsigned int) - y));
}