
unsigned char
f40 (unsigned char x, unsigned long int y)
{
  return (x >> y) | (x << (8 - y));
}