
char toLow(char c)
{
 char low = c + 32;
 return low;
}