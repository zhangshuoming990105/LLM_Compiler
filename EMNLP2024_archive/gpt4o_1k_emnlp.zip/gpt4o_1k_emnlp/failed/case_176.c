#include <stdio.h>

#include <stdlib.h>

#include <string.h>

int base2int(char b){
  switch(b){
    case 'A':
      return(0);
    case 'C':
      return(1);
    case 'G':
      return(2);
    case 'T':
      return(3);
    default:
      return(4);
  }
}