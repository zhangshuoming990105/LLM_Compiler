#include <string.h>

#include <stdio.h>

#include <stdlib.h>

unsigned int hash(char *s){
  unsigned int h=0;
  for(;*s;s++)
    h=*s+h*31;
  return h%101;
}