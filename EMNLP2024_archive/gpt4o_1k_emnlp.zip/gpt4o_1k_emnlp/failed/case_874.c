#include <stdio.h>

#include <ctype.h>

int ishtmlspace(char chr) { return ((chr == ' ' || chr == '\t' || chr == '\n' || chr == '\r')); }