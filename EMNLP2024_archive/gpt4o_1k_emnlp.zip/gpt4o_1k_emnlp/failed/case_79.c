#include <stdio.h>

#include <stdarg.h>

#include <sys/types.h>

#include <sys/stat.h>

__attribute__ ((used))
int _write(int file, char *ptr, int len)
{
# 103 "/scratch/repos/new/home/jordi_armengol_estape/c-scraper/outputs/2022-01-22/02-19-57/repos/LCRS-UCC/STM32F4Discovery-expansion/refs/heads/Working/OtharSoft/syscalls/syscalls.c"
    return len;
}