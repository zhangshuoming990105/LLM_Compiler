#include <limits.h>

int f2()
{
  return (int)(float)(2147483647);
}