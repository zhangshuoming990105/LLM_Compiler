#include <stdio.h>

#include <stdlib.h>

#include <string.h>

int eval_op(int n1,int n2,char op){
 switch(op){
  case '+':
   return n1 + n2;
  case '*':
   return n1 * n2;
  case '/':
   return n1 / n2;
 }
}