
int _poids_caractere(char c)
{
    int poids;
    switch(c)
    {
        case 'a': case 'e': case 'i': case 'l': case 'n': case 'o': case 'r': case 's': case 't': case 'u':
            poids = 1;
            break;
        case 'd': case 'g': case 'm': poids = 2;break;
        case 'b': case 'c': case 'p': poids = 3;break;
        case 'f': case 'h': case 'v': poids = 4;break;
        case 'j': case 'q': poids = 8;break;
        case 'k': case 'w': case 'x': case 'y': case 'z': poids = 10;break;
        default : poids = 0;
    }
    return poids;
}