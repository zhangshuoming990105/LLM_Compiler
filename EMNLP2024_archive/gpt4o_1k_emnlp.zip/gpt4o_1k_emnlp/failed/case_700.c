#include <stdint.h>

#include <stdbool.h>

#include <stdio.h>

#include <assert.h>

bool equalChar(const char c1, const char c2) {
    return c1 == c2;
}