#include <stdio.h>

#include <stdlib.h>

#include <math.h>

float median5(float yy,float kaa, float koo, float nee, float vii)
{
  float array[5]; float tmp;
  int i,j;

  array[0]=yy; array[1]=kaa; array[2]=koo; array[3]=nee; array[4]=vii;


  for(j=0;j<5-1;j++)
    for(i=0;i<5-1-j;i++){
      if(array[i]>array[i+1]) {
 tmp=array[i];
 array[i] = array[i+1];
 array[i+1]=tmp;
      }
    }
  return(array[2]);
}