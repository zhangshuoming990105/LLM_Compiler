#include <stdio.h>

int uchar2int(char c){
  return (int)c - 0x30;
}