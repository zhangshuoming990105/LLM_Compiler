#include <math.h>

#include <stdlib.h>

double mcdrag_rpm(double twist, double velocity)
{
  return (velocity/(twist/60.0)*12.0);
}