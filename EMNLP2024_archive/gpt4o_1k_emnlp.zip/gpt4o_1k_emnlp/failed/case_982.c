
int is_vowel (char character)
{
 int temp_ascii = (int)character;
 if ((temp_ascii == 65) || (temp_ascii == 97) || (temp_ascii == 69) || (temp_ascii == 101) ||
  (temp_ascii == 73) || (temp_ascii == 105) || (temp_ascii == 79) || (temp_ascii == 111) || (temp_ascii == 85) || (temp_ascii == 117))
 {
  return 2;
 }
 else
 {
  return 0;
 }
}