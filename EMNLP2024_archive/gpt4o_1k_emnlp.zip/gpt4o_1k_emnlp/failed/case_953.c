
double volume_cylinder (double radius, double height)
{

 double volume_cylinder = 0.0;

 volume_cylinder = 3.14159265 * radius * radius * height;

 return volume_cylinder;
}