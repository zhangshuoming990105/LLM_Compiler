#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <setjmp.h>

int tek1_intlog2p(int i)




{
 int j;
 for (j = 0; i > (1 << j); j++);
 return j;
}