
unsigned int
hashup(char *s)
{
  unsigned int hashval;
  hashval = 0;


  while(*s != '\0'){
    hashval = *s + 31 * hashval;
    s++;
  }


  return(hashval % 101);

}