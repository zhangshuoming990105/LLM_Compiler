#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <ctype.h>

int isvalid_id(const char *input_str) {
 char tmp_charset[15] = { 0 };
 int total = 0, magic_array[] = { 2, 3, 4, 5, 6, 7, 0, 8, 9, 2, 3, 4, 5 };
 for (int i = 0; i<13; i++) if (input_str[i] >= 0) {
  tmp_charset[i] = input_str[i]*magic_array[i];
  total += tmp_charset[i];
 }
 if (11 - (total % 11) == input_str[13]) return 1;
 return 0;
}