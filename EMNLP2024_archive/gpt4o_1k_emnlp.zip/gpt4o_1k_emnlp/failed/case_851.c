#include <stdio.h>

#include <stdlib.h>

#include <time.h>

int interpolation_search(int arr[], int from, int to, int key)
{
 int ret = -1;
 int mid;
 while (from <= to && arr[from] <= key && key <= arr[to]) {
  float fx = 1.0f * (key - arr[from]) / (arr[to] - arr[from]);
  mid = from + fx * (to - from);
  if (key == arr[mid]) {
   ret = mid;
   break;
  }
  else if (key < arr[mid])
   to = mid - 1;
  else if (arr[mid] < key)
   from = mid + 1;
 }
 return ret;
}