
unsigned char ConvertVIC_To_VM_Index(unsigned char VIC, unsigned char _3D_Struct)
{
    unsigned char ConvertedVIC;
    const unsigned char VIC2Index[] = {
                                0, 0, 1, 1, 2, 3, 4, 4, 5, 5,
                                7, 7, 8, 8, 10, 10, 11, 12, 12, 13,
                               14, 15, 15, 16, 16, 19, 19, 20, 20, 23,
                               23, 24, 25, 26, 27, 28, 28, 29, 29, 30,
                               31, 32, 33, 33, 34, 34, 35, 36, 37, 37,
                               38, 38, 39, 39, 40, 40, 41, 41, 42, 42
                            };

    VIC &= 0x7F;

    if (VIC < 60)
 {
        ConvertedVIC = VIC2Index[VIC];

  if (_3D_Struct != 0x0F)
  {
   switch (VIC)
   {
    case 4:
     switch(_3D_Struct)
     {
      case 0x00:
       ConvertedVIC = 43;
       break;

      case 0x03:
       ConvertedVIC = 44;
       break;

      case 0x04:
       ConvertedVIC = 45;
       break;
     }

     break;

    case 5:
     switch(_3D_Struct)
     {
      case 0x00:
       ConvertedVIC = 46;
       break;

      case 0x08:
       ConvertedVIC = 47;
       break;
     }

     break;

    case 19:
     switch(_3D_Struct)
     {
      case 0x00:
       ConvertedVIC = 48;
       break;

      case 0x03:
       ConvertedVIC = 49;
       break;

      case 0x04:
       ConvertedVIC = 50;
       break;
     }

     break;

    case 20:
     switch(_3D_Struct)
     {
      case 0x00:
       ConvertedVIC = 51;
       break;

      case 0x08:
       ConvertedVIC = 52;
       break;
     }

     break;

    case 32:
     switch(_3D_Struct)
     {
      case 0x00:
       ConvertedVIC = 53;
       break;

      case 0x03:
       ConvertedVIC = 54;
       break;

      case 0x04:
       ConvertedVIC = 55;
       break;
     }

     break;
   }
  }
 }


    else
        ConvertedVIC = VIC;

    return ConvertedVIC;
}