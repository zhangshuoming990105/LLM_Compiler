#include <unistd.h>

#include <stdio.h>

#include <stdlib.h>

#include <stdbool.h>

#include <termios.h>

int c2dir(char c){
  switch(c){
  case 'w': case 'k': case 'A':
    return 0;
  case 's': case 'j': case 'B':
    return 1;
  case 'd': case 'l': case 'C':
    return 2;
  case 'a': case 'h': case 'D':
    return 3;
  default:
    return -1;
  }
}