
unsigned int explicit_signed_char_to_unsigned_int(signed char src) {
  return (unsigned int)src;
}