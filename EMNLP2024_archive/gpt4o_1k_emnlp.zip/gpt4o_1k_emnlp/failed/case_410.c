
long nCr(long n, long r)
{
    if (n < r) return 0;


    if (r > n/2)
        return nCr(n, n-r);

    long out = 1;


    for(long k = 1; k <= r; ++k)
    {
        out *= n-k+1;
        out /= k;
    }

    return out;
}