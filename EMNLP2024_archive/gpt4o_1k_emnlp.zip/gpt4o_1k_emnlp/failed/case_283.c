#include <stdio.h>

int is_contain_star_or_sharp(const char *str)
{
 int flag =0;
 char *p = (char *)str;
 while(*p != '\0')
 {
  if(*p=='*' || *p =='#')
  {
   flag = 1;
   break;
  }
  p++;
 }
 return flag;
}