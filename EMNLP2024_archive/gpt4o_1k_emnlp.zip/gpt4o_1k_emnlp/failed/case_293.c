#include <stdio.h>

int is_in_bound(int *arr, int size, int *ptr)
{
 if(arr > ptr || (arr+size-1) < ptr)
 {
  return 0;
 }
 else
 {
  return 1;
 }
}