
long read_hz(const char* string)
{
    unsigned long result = 0;

    if (*string < '0' || *string > '9')
        return -1;

    do
        result = result * 10 + *string - '0';
    while (*++string >= '0' && *string <= '9');

    if (!*string)
        return result;
    switch (*string)
    {
    case 'G':
        result *= 1000000000;
        ++string;
        break;

    case 'M':
        result *= 1000000;
        ++string;
        break;

    case 'k':
        result *= 1000;
        ++string;

    default:;
    }
    if (*string == 'H' && *++string == 'z' && !*++string)
        return result;
    return -1;
}