
int util_hex_to_nib(char ch)
{
 int val;
 switch (ch)
 {
 case 'a':
 case 'A':
  val = 10;
  break;
 case 'b':
 case 'B':
  val = 11;
  break;
 case 'c':
 case 'C':
  val = 12;
  break;
 case 'd':
 case 'D':
  val = 13;
  break;
 case 'e':
 case 'E':
  val = 14;
  break;
 case 'f':
 case 'F':
  val = 15;
  break;
 default:
  val = (int)ch - (int)'0';
  if ((val < 0) || (val > 9))
  {
   val = -1;
  }
  break;
 }
 return val;
}