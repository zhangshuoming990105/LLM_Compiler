
unsigned char unsignedchar_ignoring_shortint(unsigned char x, short int y){return x;}