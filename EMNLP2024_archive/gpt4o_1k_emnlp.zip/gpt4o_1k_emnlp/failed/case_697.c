#include <stdio.h>

#include <stdbool.h>

#include <assert.h>

#include <math.h>

#include <stdlib.h>

int fibSumEven(int term1, int term2, int max, int sum)
{

 int term = term1 + term2;


 if(term > max) return sum;

 if(term % 2 == 0)
 {
  sum += term;
 }


 return fibSumEven(term2, term, max, sum);
}