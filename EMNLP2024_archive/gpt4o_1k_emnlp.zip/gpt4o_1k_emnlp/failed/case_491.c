#include <stdio.h>

double celsius(double fahrenheit) {
 return (fahrenheit - 32.0) * (5.0 / 9.0);
}