











int bmap2wday ( unsigned char bmap )
{
   int j;

   j = 0;
   while ( (bmap = (bmap >> 1)) != 0 )
      j++;

   return j;
}