#include <stdlib.h>

#include <stdio.h>

#include <string.h>

float inhg2hpa(float inhg)
{
    return inhg * 33.8639;
}