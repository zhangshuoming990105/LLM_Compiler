#include <stdio.h>

int f(int v, int m){ return v > 0 ? f(v / 10, m * (v % 10 ? v % 10 : 1)) : m; }