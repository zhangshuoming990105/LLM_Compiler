#include <stdio.h>

#include <stdlib.h>

#include <math.h>

#include <string.h>

#include <time.h>

#include <errno.h>

int Check(char *A, char *B, int lenght){
 int i;
 for (i = 0; i < lenght; ++i){
  if(*(A+i) != *(B+i))
   return 0;
 }
 return 1;
}