#include <stdio.h>

#include <string.h>

#include <stdlib.h>

int nofield(char *str, char sep) {
    int no;
    char *ep;

    no=0;
    for (ep=str; *ep!=0; ep++) if (*ep==sep) no++;
    if (str!=ep) no++;
    return (no);
}