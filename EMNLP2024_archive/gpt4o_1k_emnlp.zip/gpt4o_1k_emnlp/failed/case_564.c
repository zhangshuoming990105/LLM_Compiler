
int charToInt(char char_c){
if (char_c == '0')
 return (0);
else
 return (1);
}