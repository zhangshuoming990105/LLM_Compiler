
float atan_f(float x) {
 float xabs = (x < 0 ? -x : x);
 return (0.78539816339f * x - x * (xabs - 1) * (0.2447f + 0.0663f * xabs));
}