#include <stdio.h>

#include <stdbool.h>

#include <math.h>

bool is_value_in_array(int val, int *arr, int size) {

  int i;
  for (i=0; i < size; i++) {
    if (arr[i] == val) {
      return(true);
    }
  }
  return(false);
}