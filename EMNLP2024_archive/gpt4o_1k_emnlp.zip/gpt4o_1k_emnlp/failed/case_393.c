#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <ctype.h>

#include <math.h>

int is_bracket(char c) {
 switch(c) {
 case '(':
  return 1;
 case ')':
  return 2;
 default:
  return 0;
 }
}