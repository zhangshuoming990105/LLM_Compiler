#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <time.h>

#include <stdarg.h>

#include <ctype.h>

#include <sys/types.h>

#include <sys/stat.h>

#include <utime.h>

#include <fcntl.h>

#include <unistd.h>

#include <errno.h>

#include <regex.h>

int t2uprot (unsigned int prot)
{
    register unsigned tprot, uprot;
    register int tshift;
# 634 "/scratch/repos/new/home/jordi_armengol_estape/c-scraper/outputs/2022-01-22/02-19-57/repos/brouhaha/tapeutils/refs/heads/master/read20.c"
    {
 for (tshift=12, uprot=0; tshift >= 0; tshift -= 6) {
     tprot = prot >> tshift;
     uprot <<= 3;
     uprot |= (tprot >> 3) & 07;
 }
    }
    return uprot;
}