
int hex2dec4Byte(unsigned char byte3, unsigned char byte2, unsigned char byte1, unsigned char byte0){
 return (byte3<<24) + (byte2<<16) + (byte1<<8) + byte0;
}