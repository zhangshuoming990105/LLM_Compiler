#include <stdio.h>

#include <string.h>

#include <fcntl.h>

#include <unistd.h>

char mapdn( char c ){

 if( c >= 'A' && c <= 'Z' )
  return( (char)( c + 040 ));
 return( c );
}