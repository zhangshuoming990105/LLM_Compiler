#include <limits.h>

int f1()
{
  return (int)2147483648.0f;
}