






















int ILibIsDelimiter (const char* buffer, int offset, int buffersize, const char* Delimiter, int DelimiterLength)
{



 int i=0;
 int RetVal = 1;
 if (DelimiterLength>buffersize)
 {




  return(0);
 }

 for(i=0;i<DelimiterLength;++i)
 {
  if (buffer[offset+i]!=Delimiter[i])
  {



   RetVal = 0;
   break;
  }
 }
 return(RetVal);
}