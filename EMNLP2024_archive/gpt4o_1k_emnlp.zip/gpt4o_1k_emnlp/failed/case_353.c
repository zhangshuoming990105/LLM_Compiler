#include <stdio.h>

int busquedaBin1(double m[], int n, double v)
{



  int mitad, inf = 0, sup = n - 1;
  if (n == 0) return -1;

  do
  {
    mitad = (inf + sup) / 2;
    if (v > m[mitad])
      inf = mitad + 1;
    else
      sup = mitad - 1;
  }
  while( m[mitad] != v && inf <= sup);

  if (m[mitad] == v)
    return mitad;
  else
    return -1;
}