#include <stdio.h>

#include <stdlib.h>

int charTipo (char letra){
    if ((letra >= 0x41) && (letra <= 0x5A))
        return 0;

    else if (letra == 0x0A)
        return 1;

    return 2;
}