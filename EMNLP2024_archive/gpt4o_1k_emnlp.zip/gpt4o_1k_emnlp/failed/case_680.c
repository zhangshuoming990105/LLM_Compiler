
int decodedStrlen(char* str, int mlen){
 int i,c;
 for(i=0,c=0;str[i]!='\0'&&(mlen==-1||i<mlen);i++,c++){
  if(str[i]=='%'&&str[i+1]!='\0'&&str[i+2]!='\0'){
   i+=2;
  }
 }
 return c;
}