#include <math.h>

#include <stdlib.h>

double JHKeyframeAnimationFunctionEaseInQuint(double t, double b, double c, double d)
{
    return c*(t/=d)*t*t*t*t + b;
}