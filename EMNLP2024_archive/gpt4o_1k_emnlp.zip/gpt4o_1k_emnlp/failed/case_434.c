
unsigned short getushort(unsigned short x)
{
    char *p1, *p2; unsigned short y;
    p1 = (char *)(&x); p2 = (char *)(&y);
    p2[1] = p1[0]; p2[0] = p1[1];
    return(y);
}