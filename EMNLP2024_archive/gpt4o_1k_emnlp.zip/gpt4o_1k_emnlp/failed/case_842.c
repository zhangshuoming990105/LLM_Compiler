
int isNum(char c){
 return (c >= '0' && c <= '9');
}