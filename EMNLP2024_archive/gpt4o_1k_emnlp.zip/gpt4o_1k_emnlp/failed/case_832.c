
int isEndOfLine2(char ent)
{
 if(ent == 10 || ent == 13)
  return 1;

 return 0;
}