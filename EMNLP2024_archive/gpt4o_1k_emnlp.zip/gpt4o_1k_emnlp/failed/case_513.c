
int test20(int x) {
  return x && 4;



  return x && sizeof(int) == 4;


  return x && (signed char)1;

  return x || 0;
  return x || 1;
  return x || -1;

  return x || 5;

  return x && 0;
  return x && 1;
  return x && -1;


  return x && 5;


  return x || (0);
  return x || (1);
  return x || (-1);

  return x || (5);

  return x && (0);
  return x && (1);
  return x && (-1);


  return x && (5);



}