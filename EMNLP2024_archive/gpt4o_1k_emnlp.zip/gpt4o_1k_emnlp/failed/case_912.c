#include <stdio.h>

#include <string.h>

#include <stdlib.h>

char translate(char character) {
  switch(character) {
   case 'H': return 0;
   case 'C': return 1;
   case 'S': return 2;
   case 'D': return 3;
   case 'T': return 10;
   case 'J': return 11;
   case 'Q': return 12;
   case 'K': return 13;
   case 'A': return 14;
   default:
     return (int)(character - '0');
  }
}