#include <stdio.h>

int char_count(char* haystack, char needle) {
  int count = 0;







  for(char* str = haystack; *str != '\0'; str++) {



    if(*str == needle) {
      count++;
    }
  }

  return count;
}