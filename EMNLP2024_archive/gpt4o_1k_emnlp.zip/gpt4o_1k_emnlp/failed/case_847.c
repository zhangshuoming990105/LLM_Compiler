
int test18() {
  enum { A, B } a;
  switch (a) {
  case A: return 0;
  case B: return 1;
  case 7: return 1;
  default: return 2;
  }
}