#include <stdio.h>

int test2()
{
 int i;
 int b[10];
 int *p = b;
 for (i = 0; i < 10; i++)
  *p++ = i;

 return 0;
}