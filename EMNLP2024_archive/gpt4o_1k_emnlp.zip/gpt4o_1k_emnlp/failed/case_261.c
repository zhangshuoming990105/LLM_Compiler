#include <stdlib.h>

#include <math.h>

double binomial(int n, int k) {
  int i;
  double x = 1;

  for (i = 0; i < k; ++i) {
    x *= n - i;
    x /= k -i;
  }

  return x;
}