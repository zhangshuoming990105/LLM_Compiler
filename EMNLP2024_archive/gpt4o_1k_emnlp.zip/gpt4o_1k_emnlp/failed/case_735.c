
int gregorian_is_leap_year(int year)
{
 return !(year % 100 ? year % 4 : year % 400);
}