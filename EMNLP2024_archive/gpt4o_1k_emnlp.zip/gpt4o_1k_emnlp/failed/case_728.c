#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <errno.h>

#include <unistd.h>

#include <fcntl.h>

#include <sys/stat.h>

int ho_strlen(const char *str) {
    char *p = (char *)str;
    while (*p++)
        ;
    return p - str - 1;
}