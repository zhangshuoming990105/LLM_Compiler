
unsigned char
f63 (unsigned char x, unsigned int y)
{
  return (x << (8 * sizeof (unsigned char) - y)) ^ (x >> y);
}