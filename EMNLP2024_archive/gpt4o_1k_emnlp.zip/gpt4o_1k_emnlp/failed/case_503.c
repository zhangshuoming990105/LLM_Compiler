#include <math.h>

double topocentric_azimuth_angle_zero_360 (double azimuth180)
{
    return azimuth180 + 180.0;
}