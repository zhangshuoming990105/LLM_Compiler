#include <math.h>

double bitflip(double a) {

    int xbitWidth = 32;
    unsigned int mask = ( unsigned int ) -1 >> (32 - xbitWidth);
    unsigned int tmp = a < 0 ? (int) a : (unsigned) a;
    return (double) ( ~tmp & mask ) ;
}