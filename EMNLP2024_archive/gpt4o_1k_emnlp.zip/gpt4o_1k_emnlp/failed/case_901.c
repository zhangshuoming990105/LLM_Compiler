
int my_atoi(char *str)
{
 int neg;
 int nbr;

 neg = 0;
 while (*str == '-')
 {
  str++;
  neg++;
 }
 nbr = 0;
 while (*str >= '0' && *str <= '9')
 {
  nbr = nbr * 10 + *str - '0';
  str++;
 }
 if (!(neg % 2))
  return (nbr);
 else
  return (-nbr);
}