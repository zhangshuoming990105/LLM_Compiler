#include <stdio.h>

#include <assert.h>

int bic(int x, int m) {
    return x & (~m);
}