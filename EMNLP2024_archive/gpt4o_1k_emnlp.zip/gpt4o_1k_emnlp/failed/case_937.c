#include <stdio.h>

int isPrime(int n)
{
 int i=2,j=0;
 while(n%i != 0 && i++<n)j++;

 if(j == (n-2))
  return 1;
 else
  return 0;
}