
double interp_4(double phim1, double phi, double phip1, double phip2){
    return (7.0/12.0)*(phi + phip1 ) -(1.0/12.0)*(phim1 + phip2);
}