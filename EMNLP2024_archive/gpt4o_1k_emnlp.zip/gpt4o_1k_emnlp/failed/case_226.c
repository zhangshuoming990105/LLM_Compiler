#include <string.h>

int fchar_cmp(const char a, const char b) { return (int)a - (int)b; }