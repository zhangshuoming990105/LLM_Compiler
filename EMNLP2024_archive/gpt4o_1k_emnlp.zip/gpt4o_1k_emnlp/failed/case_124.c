#include <stdio.h>

#include <stdlib.h>

#include <math.h>

int same_coordinate(int* coor1, int* coor2, int d)
{
    int i;
    for(i = 0; i < d; i++)
 if(coor1[i] != coor2[i])
     return 0;
    return 1;
}