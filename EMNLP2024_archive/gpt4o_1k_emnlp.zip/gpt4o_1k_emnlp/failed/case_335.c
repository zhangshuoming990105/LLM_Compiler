
int associatedConnectivity(int connectivity)
{
  switch(connectivity)
    {
    case 1:
      return 2;
      break;
    case 2:
      return 1;
      break;
    case 3:
      return 4;
      break;
    case 4:
      return 3;
      break;
    default:
      return 2;
      break;
    }
  return 0;
}