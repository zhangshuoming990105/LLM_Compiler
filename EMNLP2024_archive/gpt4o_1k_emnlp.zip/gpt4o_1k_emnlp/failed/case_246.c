#include <stdio.h>

long hash(char* word)
{
 int counter=0;
 long hashed = 42;

 while(word[counter] != '\0')
 {
  hashed += word[counter]*(counter+1);
  counter ++;
 }

 return hashed;
}