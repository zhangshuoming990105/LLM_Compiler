
unsigned long
hash_sdbm (char* str)
{
    unsigned long hash = 0;
    unsigned long c;

    while ((c = *str++) != '\0') {
        hash = c + (hash << 6) + (hash << 16) - hash;
    }

    return hash;
}