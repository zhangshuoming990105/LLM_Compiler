#include <stdio.h>

char get_opposite_letter(char c) {
    char middle = 'a' + (('z' - 'a') / 2);
    char letter_distance_from_middle = middle - c;

    middle++;

    return letter_distance_from_middle + middle;
}