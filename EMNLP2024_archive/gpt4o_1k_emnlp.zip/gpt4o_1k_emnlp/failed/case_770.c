#include <wchar.h>

int uft8towcs_octetcount(char c)
{
   char mask = (char)0xfc;
   int retval = 6;

   if ((c & 0x80) == 0)
      return 1;


   while ((c & mask) != mask && retval > 0)
   {
      retval--;
      mask <<= 1;
   }

   return retval;
}