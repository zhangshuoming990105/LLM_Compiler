
float test1f(float a) { return -a; }