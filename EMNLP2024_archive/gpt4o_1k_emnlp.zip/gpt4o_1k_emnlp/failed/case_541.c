#include <string.h>

int motTrouve(char *mot_bis)
{
 int i = 0;

 while (*(mot_bis + i) != 0)
 {
  if (*(mot_bis + i) == '\xB8')
  {
   return 0;
  }
  i++;
 }
 return 1;
}