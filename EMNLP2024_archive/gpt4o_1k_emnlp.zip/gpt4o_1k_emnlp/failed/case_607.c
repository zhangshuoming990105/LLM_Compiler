#include <stdio.h>

#include <stdlib.h>

#include <string.h>

char *debug_state(int s)
{
  switch( s )
  {
    case 1: return "START";
    case 2: return "IN_TOKEN";
    case 3: return "IN_TOKEN_NEEDING_DELIM";
    case 4: return "IN_TOKEN_AFTER_ESCAPE";
    case 5: return "IN_TOKEN_AFTER_INNER_ESCAPE";
    case 6: return "STOP";
    default: return "?";
  }
}