
double interp_8(double phim3, double phim2, double phim1, double phi,
                double phip1, double phip2, double phip3, double phip4){
   return (533./840. * (phi + phip1) - 139.0/840.0 * (phim1 + phip2 )
            + 29.0/840.0 * (phim2 + phip3) -1.0/280.0*(phim3 + phip4));
}