#include <stdio.h>

#include <time.h>

#include <stdlib.h>

#include <limits.h>

#include <ctype.h>

int isnum(char *c) {
 int i = 0;

 while( *(c + i) != '\0' ) {
  if ( !(*(c + i) >= 48 && *(c + i) <= 57) )
   break;
  else
   i++;
 }
 if ( *(c + i) == '\0' )
  return 1;
 else
  return 0;
}