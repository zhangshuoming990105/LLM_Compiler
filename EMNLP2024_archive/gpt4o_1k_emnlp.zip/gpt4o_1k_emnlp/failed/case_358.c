#include <stdio.h>

double power(double n, int p)
{
 double pow = 1;
 int i;

 for (i = 1; i <= p; i++)
  pow *= n;

 return pow;
}