
char CaesarDe(char c)
{
 char out = c - 3;
 return out;
}