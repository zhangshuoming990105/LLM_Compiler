
float grad2( int hash, float x, float y ) {
    int h = hash & 7;
    float u = h<4 ? x : y;
    float v = h<4 ? y : x;
    return ((h&1)? -u : u) + ((h&2)? -2.0*v : 2.0*v);
}