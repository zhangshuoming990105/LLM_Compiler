#include <stdio.h>

#include <stdlib.h>

#include <stdbool.h>

int maior_valor_matriz(int matriz[4][4])
{
    int maior=0,i,j;
    for(i=0;i<4;i++){
        for(j=0;j<4;j++){
            if(matriz[i][j]>maior)
                maior=matriz[i][j];
        }
    }
 return maior;
}