
unsigned short int
f62 (unsigned short int x, unsigned long int y)
{
  return (x << ((-y) & (8 * sizeof (unsigned short) - 1))) ^ (x >> y);
}