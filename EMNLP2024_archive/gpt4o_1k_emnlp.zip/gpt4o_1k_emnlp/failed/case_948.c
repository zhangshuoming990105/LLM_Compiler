
unsigned short int
f54 (unsigned short int x, unsigned long int y)
{
  return (x << ((-y) & (8 * 2 - 1))) ^ (x >> y);
}