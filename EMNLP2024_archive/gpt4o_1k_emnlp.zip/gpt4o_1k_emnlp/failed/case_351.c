#include <stdio.h>

char node_name(int n) { return ('A' + n); }