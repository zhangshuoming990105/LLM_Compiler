#include <stdio.h>

#include <stdlib.h>

#include <stdbool.h>

#include <time.h>

unsigned int cut( unsigned int length ) {
 if (length % 2 == 0)
  return length/2;
 else
  return length/2 + 1;
}