#include <stdlib.h>

#include <stdio.h>

#include <string.h>

void transformNeigh ( int n[27], int dir, int USn[27] )
{
 int i, j, k;
 int tmp[27];

 switch(dir) {
  case 0:

   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (j)*(3) + (i) + (k)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;


  case 3:


   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (j)*(3) + (i) + (k)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

  case 6:


   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (2-i)*(3) + (j) + (k)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

  case 10:


   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (j)*(3) + (k) + (2-i)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;
  case 4:


   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (j)*(3) + (2-k) + (i)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

  case 11:

   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (2-j)*(3) + (i) + (k)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

  case 7:


   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (j)*(3) + (i) + (2-k)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

  case 5:



   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      tmp[( (j)*(3) + (i) + (2-k)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }

   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (2-j)*(3) + (i) + (k)*(3)*(3) )] = tmp[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

 case 8:


   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      tmp[( (j)*(3) + (k) + (2-i)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }

   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (2-j)*(3) + (i) + (k)*(3)*(3) )] = tmp[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

  case 2:

   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      tmp[( (j)*(3) + (2-k) + (i)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }

   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (2-j)*(3) + (i) + (k)*(3)*(3) )] = tmp[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

  case 1:


   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      tmp[( (j)*(3) + (i) + (2-k)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }

   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (i)*(3) + (2-j) + (k)*(3)*(3) )] = tmp[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

  case 9:


   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      tmp[( (j)*(3) + (i) + (2-k)*(3)*(3) )] = n[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }

   for(k=0; k < 3; k++) {
    for(j=0; j < 3; j++) {
     for(i=0; i < 3; i++) {
      USn[( (2-i)*(3) + (j) + (k)*(3)*(3) )] = tmp[( (j)*(3) + (i) + (k)*(3)*(3) )];
     }
    }
   }
   break;

 }
}