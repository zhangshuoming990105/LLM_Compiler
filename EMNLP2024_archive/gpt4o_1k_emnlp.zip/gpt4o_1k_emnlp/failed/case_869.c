#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <ctype.h>

#include <stdio.h>

int is_hex_digit ( char c )
{
    return (c >= '0' && c <= '9' ) || ( c >= 'a' && c <= 'f' ) ||
        ( c >= 'A' && c <= 'F' );
}