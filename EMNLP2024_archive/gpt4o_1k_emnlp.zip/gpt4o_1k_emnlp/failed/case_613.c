
int yamadie(char n)
{
    if(n>='A'&&n<='Z')
        return 1;
    else if(n>='a'&&n<='z')
        return 2;
    else if(n>='0'&&n<='9')
        return 3;
    else
        return 4;
}