#include <string.h>

#include <sys/stat.h>

#include <sys/time.h>

#include <time.h> 

#include <time.h>

#include <unistd.h>

#include <errno.h>

#include <stdio.h>

#include <stdlib.h>

#include <stdarg.h>

int EndianTest(void)
{
  unsigned long int CT = 0L;
  ((char*)(&CT))[0] = 1;
  return ((CT==1)?0:1);
}