
double QuinticEaseIn(double p)
{
    return p * p * p * p * p;
}