#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <ctype.h>

unsigned int BKDRHash(char *str)
{
    unsigned int seed = 31, hash = 0;
    while (*str) {
        hash = (hash<<5) - hash + (*str++);
    }
    return (hash % 1000);
}