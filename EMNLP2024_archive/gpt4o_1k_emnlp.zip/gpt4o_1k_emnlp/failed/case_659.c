#include <sys/types.h>

#include <sys/socket.h>

#include <sys/stat.h>

#include <sys/un.h>

#include <sys/time.h>

#include <netinet/in.h>

#include <netinet/tcp.h>

#include <arpa/inet.h>

#include <sys/poll.h>

#include <unistd.h>

#include <fcntl.h>

#include <string.h>

#include <netdb.h>

#include <errno.h>

#include <stdarg.h>

#include <stdio.h>

int anetRead( int fd , char *buf , int count )
{
 int nread,totlen = 0;
 while (totlen != count)
 {
  nread = read( fd , buf , count - totlen );
  if (nread == 0)
  {
   return totlen;
  }
  if (nread == -1)
  {
   return -1;
  }
  totlen += nread;
  buf += nread;
 }
 return totlen;
}