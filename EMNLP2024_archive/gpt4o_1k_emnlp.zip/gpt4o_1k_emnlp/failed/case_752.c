
int
test04 (char* a, short* b, int c, int d)
{
  if (*a & *b)
    return c;
  return d;
}