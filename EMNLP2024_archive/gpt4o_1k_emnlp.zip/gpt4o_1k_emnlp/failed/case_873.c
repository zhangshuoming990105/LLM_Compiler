#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <ctype.h>

int iscmoji(char a)
{
  if(a >= 'a' && a <= 'z'){
    return 1;
  }
  if(a >= 'A' && a <= 'Z'){
    return 1;
  }
  if(a >= '0' && a <= '9'){
    return 1;
  }
  if(a == '_'){
    return 1;
  }
  return 0;
}