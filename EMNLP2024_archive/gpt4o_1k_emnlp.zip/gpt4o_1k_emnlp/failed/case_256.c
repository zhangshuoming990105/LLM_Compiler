
unsigned int fuzz(unsigned int bizz[][10]) {
    return bizz[1][1];
}