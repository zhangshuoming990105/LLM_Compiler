#include <stdio.h>

double celsius(double f)
{
  return 5. / 9. * (f - 32);
}