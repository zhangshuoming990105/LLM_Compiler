#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <ctype.h>

char *
escape_char(char e)
{
    switch (e) {
        case 'a':
            return "\a";
        case 'b':
            return "\b";
        case 't':
            return "\t";
        case 'n':
            return "\n";
        case 'v':
            return "\v";
        case 'f':
            return "\f";
        case 'r':
            return "\r";
        case '\"':
            return "\"";
        case '\'':
            return "\'";
        case '\\':
            return "\\";
        default:
            return "\?";
    }
}