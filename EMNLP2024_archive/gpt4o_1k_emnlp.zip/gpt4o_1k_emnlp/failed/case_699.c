
int cntOddDigits(int data)
{
 int cnt=0,k;
 while(data!=0)
 {
          k=data%10;
           if((k!=0)&&(k%2==1))
  cnt++;
          data/=10;
 }

 return cnt;
}