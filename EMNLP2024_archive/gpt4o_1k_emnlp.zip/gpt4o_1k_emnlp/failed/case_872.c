#include <stdlib.h>

#include <stdio.h>

#include <stdarg.h>

#include <unistd.h>

#include <string.h>

#include <signal.h>

#include <time.h>

#include <ctype.h>

#include <limits.h>

int
gui_color_attr_get_flag (char c)
{
    if (c == '*')
        return 0x0200000;

    if (c == '!')
        return 0x0400000;

    if (c == '/')
        return 0x0800000;

    if (c == '_')
        return 0x1000000;

    if (c == '|')
        return 0x2000000;

    return 0;
}