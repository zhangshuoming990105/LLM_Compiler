#include <stdio.h>

int in_out_loc(int internal_src, int internal_dst, int dir)
{
   if(internal_src && !internal_dst)
   {
     if(dir == 1)
        return 1;
     else
        return 2;
   } else
   if(!internal_src && internal_dst)
   {
     if(dir == 1)
        return 2;
     else
        return 1;
   } else
      if(internal_src && internal_dst)
   {
        return 3;
   } else

    return 4;



}