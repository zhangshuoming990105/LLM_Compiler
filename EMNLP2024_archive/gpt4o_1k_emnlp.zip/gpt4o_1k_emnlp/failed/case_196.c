#include <time.h>

#include <stdlib.h>

int isInTable(int nombre, int * tab, int nb)
{
    int i=0;
    int retour =0;
    while (i < nb && !retour)
    {
        if(tab[i] == nombre) retour=1;
        i++;
    }
    return retour;
}