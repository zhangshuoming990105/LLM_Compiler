#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <ctype.h>

unsigned char ascii_to_ch(unsigned char c)
{
 if (c < 32) return 0;
 if (c > 63) return 0;

 return (c - 32);
}