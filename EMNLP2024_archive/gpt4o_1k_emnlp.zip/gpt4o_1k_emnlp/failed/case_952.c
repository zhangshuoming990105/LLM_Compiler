#include <stdio.h>

#include <stdbool.h>

volatile bool buttonUp (volatile unsigned int *p ){
    static bool b=false;
    if(((*p) & 0x00000010) == 0x00000010){
        if (b==false)
        {
            b=true;
            return true;
        }
        else
            return false;
    }
    b=false;
    return false;
}