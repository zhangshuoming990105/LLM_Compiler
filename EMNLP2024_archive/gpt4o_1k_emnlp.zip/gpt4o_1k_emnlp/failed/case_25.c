#include <stdlib.h>

#include <stdio.h>

#include <string.h>

#include <errno.h>

char flip_bit (char bit_character) {
 if ('0' == bit_character)
  return '1';
 else
  return '0';
}