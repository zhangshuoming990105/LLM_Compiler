
unsigned char
f16 (unsigned char x, unsigned long int y)
{
  return (x << y) | (x >> (8 * sizeof (unsigned char) - y));
}