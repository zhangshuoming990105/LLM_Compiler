#include <stdio.h>

double berechne_durchschnittsverbrauch_l_pro_100km(double strecke, double verbrauch)
{
 double durchschnittsverbrauch = verbrauch / (strecke / 100);

 return durchschnittsverbrauch;
}