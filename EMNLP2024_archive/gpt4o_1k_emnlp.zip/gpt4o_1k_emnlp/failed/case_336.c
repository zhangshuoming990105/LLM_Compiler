#include <stdlib.h>

#include <stdio.h>

char first_empty_cell(char *cell, char minimum) {
   char first_empty = minimum;
   while(first_empty == cell[0] || first_empty == cell[1] ||
         first_empty == cell[2] || first_empty == cell[3] ||
         first_empty == cell[4])
      first_empty++;
   return first_empty;
}