#include <stdio.h>

double EstimatePi(int iterations)
{
    double pi = 1;

    for(int i = 3; i < iterations * 2; i = i + 4)
    {
        pi = pi - (1.0/i) + (1.0/(i + 2.0));
    }

    return pi * 4;
}