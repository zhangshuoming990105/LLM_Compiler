#include <stdio.h>

int invert(int x, unsigned int p, unsigned int n)
{
 int a;
 int i;

 a = x & ~(~(~0 << n) << (p - n + 1));
 i = (~((x >> (p - n + 1)) & ~(~0 << n)) & ~(~0 << n)) << (p - n + 1);
 x = a | i;
 return x;
}