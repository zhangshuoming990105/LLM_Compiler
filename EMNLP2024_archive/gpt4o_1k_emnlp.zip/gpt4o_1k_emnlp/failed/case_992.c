

int check_hex(char *str, int len) {
 int i;
 for (i = 0; i < len; i++) {
  if ((str[i] < '0' && str[i] > '9') && (str[i] < 'a' && str[i] > 'f') && (str[i] < 'A' && str[i] > 'F')
   ) {
   return 0;
  }
 }

 return 1;

}