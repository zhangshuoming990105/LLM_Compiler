#include <stdio.h>

int compare(int array1[], int array2[],int col)
{
int result=1;
int c;
for(c=0; c<col; c++)
 {
  if(array1[c]!=array2[c])
  {
   result=0;
   return result;
  }
 }
return result;
}