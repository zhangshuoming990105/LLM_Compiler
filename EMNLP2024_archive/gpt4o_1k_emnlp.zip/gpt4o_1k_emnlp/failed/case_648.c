
int byte_lshift(unsigned char x, unsigned char y) {
    x <<= y;
    return x;
}