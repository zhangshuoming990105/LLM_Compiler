#include <stdio.h>

int hash(char string[]) {
    int index = 0;
    int code = 0;
    while(string[index] != '\0') {
        code += string[index];
        ++index;
    }
    return code;
}