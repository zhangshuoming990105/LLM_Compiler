
int next_pow_2(int n) {

 if(n&(n-1) == 0) {
  return n;
 }
 int p = 1;
 while(p<n) {
  p = p << 1;
 }
 return p;
}