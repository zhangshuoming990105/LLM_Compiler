
unsigned int
f58 (unsigned int x, long int y)
{
  return (x << (8 * sizeof (unsigned int) - y)) ^ (x >> y);
}