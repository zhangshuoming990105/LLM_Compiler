#include <stdio.h>

#include <stdlib.h>

#include <errno.h>

#include <string.h>

#include <ctype.h>

#include <math.h>

#include <time.h>

double rad2deg(double ang)
{
    return ang * 180.0 / 3.141592653589793;
}