#include <stdlib.h>

#include <stdio.h>

#include <math.h>

int is_leaf(int m, int t) {
  static int leaf[6] = {7, 5, 4, 4, 3, 3};
  if (m < 6)
    return (t <= 32);
  else if (m > 16)
    return (t <= 1);
  else if (m > 11)
    return (t <= 2);
  else
    return (leaf[m - 6] >= t);
}