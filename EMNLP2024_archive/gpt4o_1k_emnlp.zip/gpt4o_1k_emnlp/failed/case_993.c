
unsigned char
f40 (unsigned char x, unsigned long int y)
{
  return (x >> y) | (x << ((-y) & (8 - 1)));
}