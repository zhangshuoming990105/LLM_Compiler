#include <stdlib.h>

int my_str_isalpha(char *str)
{
  int lp;

  if (str == NULL)
    return (1);
  lp = 0;
  while (str[lp] != '\0')
    {
      if ((str[lp] >= 0 && str[lp] < 65) || (str[lp] > 90 && str[lp] < 97) ||
   (str[lp] > 122))
 return (0);
      ++lp;
    }
  return (1);
}