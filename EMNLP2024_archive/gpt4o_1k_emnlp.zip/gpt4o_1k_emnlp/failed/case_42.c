
float obdConvert_44 (unsigned int A, unsigned int B, unsigned int C, unsigned int D) {
 return ((float)A*256.0f+(float)B)*0.0000305f;
}