
int cmp(const int* a, const int* b) {
 return *a < *b ? -1 : 1;
}