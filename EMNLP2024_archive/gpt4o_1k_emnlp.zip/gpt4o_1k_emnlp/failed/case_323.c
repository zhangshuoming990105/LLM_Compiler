#include <stdio.h>

int is_num( char c )
{
 return ( c >= '0' && c <= '9' ) ? 1 : 0;
}