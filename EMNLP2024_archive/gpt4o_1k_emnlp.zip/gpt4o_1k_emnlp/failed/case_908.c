#include <stdio.h>

int binsearch( int x, int ord_set[], int maxima )
{
 int low, mid, high;

 low = 0;
 high = maxima - 1;

 while( low <= high )
 {
  mid = ( low + high ) / 2;

  if( x < ord_set[ mid ] )
  {
   high = mid - 1;
  }
  else if( x > ord_set[ mid ] )
  {
   low = mid + 1;
  }
  else
  {
   return mid;
  }
 }

 return -1;
}