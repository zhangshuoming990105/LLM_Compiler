#include <stdio.h>

#include <stdlib.h>

#include <stdint.h>

#include <stdarg.h>

#include <string.h>

#include <ctype.h>

int bits_required_signed(int min, int max)
{
 int n = 2;

 if (min > 0) min = 0;
 if (max < 0) max = 0;

 while (min < -(1 << (n-1))) n++;
 while (max >= (1 << (n-1))) n++;

 return n;
}