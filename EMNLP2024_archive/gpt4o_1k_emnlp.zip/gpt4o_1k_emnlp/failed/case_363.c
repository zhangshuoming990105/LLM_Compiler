#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <ctype.h>

#include <limits.h>

#include <stdbool.h>

#include <errno.h>

#include <math.h>

double sd2eps(unsigned int sigdig)
{
  double eps = 1;

  while (sigdig > 0)
  {
    eps *= 0.1;
    sigdig -= 1;
  }

  return eps;
}