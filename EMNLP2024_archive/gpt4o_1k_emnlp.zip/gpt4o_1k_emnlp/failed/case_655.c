
unsigned int convert(unsigned int ucX)
{
 return (ucX == 0)?:(1 << (ucX-3) );
}