#include <math.h>

double pp_sqrt(double n)
{
# 91 "/scratch/repos/new/home/jordi_armengol_estape/c-scraper/outputs/2022-01-22/02-19-57/repos/wanborj/PSEFM/refs/heads/master/benchmark/sw/lib/c/math.c"
}