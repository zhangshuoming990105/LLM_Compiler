#include <stdio.h>

int logicOr(int x, int y) {
 if (x || y == 1) {
  return 1;
 }
 else {
  return 0;
 }
}