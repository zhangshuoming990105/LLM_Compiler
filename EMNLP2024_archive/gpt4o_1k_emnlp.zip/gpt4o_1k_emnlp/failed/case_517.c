#include <stdio.h>

#include <stdlib.h>

int heap_pai(int n) {
    return ((int) n/2);
}