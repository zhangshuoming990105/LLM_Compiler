



int _isfmt(char c)
{
 switch (c) {
 case 's':
 case 'd':
 case 'x':
 case 'o':
 case 'c':
  return 1;
 default:
  return 0;
 }
}