#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <omp.h>

int
current_agent(int i) { return i % 2; }