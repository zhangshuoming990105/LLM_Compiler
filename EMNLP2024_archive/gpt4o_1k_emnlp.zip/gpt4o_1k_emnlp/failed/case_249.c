#include <stdio.h>

#include <string.h>

char symbolToDraw(char condition, float avgTemp){

   char symbolFunction5;

    if (condition == 's')
        symbolFunction5 = '@';

    else if (condition == 'c')
        symbolFunction5 = '~';

    else if (condition == 'p' && avgTemp <= 0)
        symbolFunction5 = '*';

    else
        symbolFunction5 = ';';


    return symbolFunction5;
}