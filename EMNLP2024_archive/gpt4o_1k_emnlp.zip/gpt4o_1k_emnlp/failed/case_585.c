
int vtweak(int value, int shift, int scale)
{
 return((int)(((((value+(shift<<1)-255-127.5)*scale/(double)(256-scale)+127.5)>(0)?((value+(shift<<1)-255-127.5)*scale/(double)(256-scale)+127.5):(0)))>(255)?(255):((((value+(shift<<1)-255-127.5)*scale/(double)(256-scale)+127.5)>(0)?((value+(shift<<1)-255-127.5)*scale/(double)(256-scale)+127.5):(0)))));
}