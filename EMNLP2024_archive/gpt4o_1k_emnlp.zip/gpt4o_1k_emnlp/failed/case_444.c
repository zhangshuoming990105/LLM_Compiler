#include <stdio.h>

int c_sensitive(char *a, char *b)
{
 int x;

 for(x=0; a[x] != '\0' && b[x] != '\0'; x++)
 {
  if(a[x] > b[x])
  return 1;
  else if(a[x] < b[x])
   return -1;
 }

 return 0;
}