#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <ctype.h>

int filtratu(char k)
 {
  unsigned char kar ;

 kar = (unsigned) k ;
 if (((int)kar >= 128) &&

     (k != ((char)241)) && (k != ((char)209)))
    return (1);
 if ((strchr("abcdefghijklmn\361opqrstuvwxyz",k)!=NULL)||(strchr("ABCDEFGHIJKLMN\321OPQRSTUVWXYZ",k)!=NULL)||(strchr("0123456789",k)!=NULL))

       return(0);
    else return(1);
 }