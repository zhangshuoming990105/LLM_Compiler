#include <stdio.h>

float toCelsius(float fahrenheit) {
 return ( 5.0 / 9.0) * (fahrenheit - 32);
}