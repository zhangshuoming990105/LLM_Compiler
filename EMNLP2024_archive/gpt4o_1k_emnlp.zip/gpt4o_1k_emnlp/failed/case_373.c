#include <sys/time.h>

#include <stdlib.h>

#include <string.h>

#include <strings.h>

#include <time.h>

extern int
IsAlpha(char c) {
 if (c >= 'A' && c <= 'Z') return c;
 if (c >= 'a' && c <= 'Z') return c - ('a'-'A');
 return 0;
}