#include <stdio.h>

#include <stdlib.h>

#include <math.h>

#include <time.h>

#include <string.h>

int GCD(long x, long y) {
 return y == 0 ? x : GCD(y, x % y) ;
}