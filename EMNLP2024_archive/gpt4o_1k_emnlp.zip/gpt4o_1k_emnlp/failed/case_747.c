#include <stdlib.h>

int isPermutation (int array[], int n) {
  int value_count[n+1];

  for ( int i = 0; i < n; i++ ) {
    if ( array[i] < 1 || array[i] > n || value_count[array[i]] == 1 )
      return 0;
    else
      value_count[array[i]] = 1;
  }

  return 1;
}