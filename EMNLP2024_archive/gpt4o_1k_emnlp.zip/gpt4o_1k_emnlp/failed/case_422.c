#include <stdio.h>

int volesfera(int r){
 int vol;

 vol=4/3*3.141592654*(r*r*r);
 return vol;
}