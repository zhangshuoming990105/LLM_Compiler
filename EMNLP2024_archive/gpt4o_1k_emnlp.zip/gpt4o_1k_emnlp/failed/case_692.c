#include <stdio.h>

#include <stddef.h>

#include <stdlib.h>

#include <time.h>

#include <string.h>

#include <ctype.h>

unsigned long bintol(const char *str)
{
 unsigned long sum = 0L;

 while (*str) {
  switch (*str) {
  case '1':
   sum <<= 1;
   ++sum;
   break;
  case '0':
   sum <<= 1;
   break;
  case '_':
   break;
  default:
   return sum;
  }

  ++str;
 }

 return sum;
}