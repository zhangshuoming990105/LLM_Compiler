




int CdsObjectToDidl_Helper_DoubleEscapeLength(const char* data)
{
 int i = 0, j = 0;
 while (data[i] != 0)
 {
  switch (data[i])
  {
   case '"':
   j += 10;
   break;
   case '\'':
   j += 10;
   break;
   case '<':
   j += 8;
   break;
   case '>':
   j += 8;
   break;
   case '&':
   j += 9;
   break;
   default:
   j++;
  }
  i++;
 }
 return j;
}