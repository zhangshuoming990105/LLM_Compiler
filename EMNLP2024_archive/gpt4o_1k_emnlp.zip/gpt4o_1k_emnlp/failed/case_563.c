#include <string.h>

#include <stdlib.h>

#include <stdio.h>

#include <math.h>

#include <ctype.h>

float degree2decimal(float d, float m, float s) {
    return d+(m/60)+(s/3600);
}