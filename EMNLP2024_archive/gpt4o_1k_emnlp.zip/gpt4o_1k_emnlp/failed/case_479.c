#include <stdio.h>

int my_str_length(const char *p)
{
    int count=0;
    while(*p)
    {
        count +=1;
        p++;
    }
    return count;
}