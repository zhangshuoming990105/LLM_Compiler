#include <signal.h>

#include <sys/wait.h>

#include <sys/select.h>

#include <unistd.h>

unsigned long int
thread_get_id(void)
{
 static unsigned long int counter = 0;
 return ++counter;
}