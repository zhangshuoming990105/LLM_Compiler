#include <stdio.h>

int ParseInt(const char* str, int len) {
 const char* cursor = str;
 int val = 0;
 int sign = 1;
 int isHex = 0;

 if (*cursor == '-') {
  cursor++;
  sign = -1;
 }
 else if (*cursor == '0' && cursor[1] == 'x') {
  cursor += 2;
  isHex = 1;
 }

 const int base = (isHex ? 16 : 10);
 while (*cursor && (cursor - str) < len) {
  int digit = (*cursor - '0');

  if (isHex && *cursor >= 'A' && *cursor <= 'F') {
   digit = (*cursor - 'A') + 10;
  }

  val *= base;
  val += digit;
  cursor++;
 }

 return val * sign;
}