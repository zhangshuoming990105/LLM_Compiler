#include <stdlib.h>

#include <string.h>

#include <ctype.h>

#include <math.h>

char get_char_comp(char c) {
  int i = c - 65;
  if (i < 0 || i > 57) {
    return c;
  } else {
    return "TVGHEFCDIJMLKNOPQYWAABSXRZ[\\]^_`tvghefcdijmlknopqywaabsxrz"[i];
  }
}