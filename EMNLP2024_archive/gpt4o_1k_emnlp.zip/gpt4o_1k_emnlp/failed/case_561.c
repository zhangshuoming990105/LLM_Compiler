
int move_closer(int current, int goal)
{
 if (current > goal)
 {
  return current ++;
 }
 else if (current < goal)
 {
  return current --;
 }
 else
 {
  return current;
 }
}