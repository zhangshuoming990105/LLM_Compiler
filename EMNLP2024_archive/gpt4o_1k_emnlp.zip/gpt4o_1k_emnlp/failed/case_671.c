
unsigned short int
f5 (unsigned short int x, unsigned int y)
{
  return (x << y) | (x >> ((-y) & (8 * 2 - 1)));
}