
float f2(float x, short y)
{
  return x * y;
}