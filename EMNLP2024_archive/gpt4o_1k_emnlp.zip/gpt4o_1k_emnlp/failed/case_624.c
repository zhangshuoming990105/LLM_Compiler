#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <errno.h>

int isbase64(char c) {
   return !!(c && strchr("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", c) != NULL);
}