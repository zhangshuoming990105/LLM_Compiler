#include <memory.h>

#include <stdio.h>

#include <stdlib.h>

#include <math.h>

double
dChoose( long lNum, long lDenom )
{
    long lStart;

    double dResult;
    long i, j;

    if ( lNum < lDenom )
        return 0.0;



    if ( lNum < 0.0l || lDenom < 0.0l )

        return 0.0;

    if ( lDenom > lNum - lDenom ) {
        lStart = lDenom;
        lDenom = lNum - lDenom;
    } else {
        lStart = lNum - lDenom;
    }

 dResult = 1.0;
 i = lNum;
 j = lDenom;
 while ( i > lStart || j > 1 ) {
  if ( i > lStart ) {
   if ( j > 1 )
    dResult *= ( (double)i-- / j-- );
   else
    dResult *= i--;
  } else if ( j > 1 )
   dResult /= j--;
 }
# 87 "/scratch/repos/new/home/jordi_armengol_estape/c-scraper/outputs/2022-01-22/02-19-57/repos/swihart/repeated/refs/heads/master/src/calcs.c"
 return( dResult );
}