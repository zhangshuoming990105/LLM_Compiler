#include <string.h>

#include <ctype.h>

int line_isblank(char *line)

{
char *next;
int rc;

rc = 0;

for (next = line; *next == ' '; next++) ;

if (*next == '\n')
   {
   next++;
   if (*next == '\0') rc = 1;
   }

return rc;
}