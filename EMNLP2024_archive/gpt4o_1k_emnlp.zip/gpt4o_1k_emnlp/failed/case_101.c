




char MungeHexDigit(char* one_hexdigit)
{
 char r = -1;
 char c = *one_hexdigit;
 if (c >= '0' && c <= '9')
 {
  r = c - '0';
 }
 else if (c >= 'A' && c <= 'F')
 {
  r = c - 'A' + 10;
 }
 else if (c >= 'a' && c <= 'F')
 {
  r = c - 'a' + 10;
 }

 return r;
}