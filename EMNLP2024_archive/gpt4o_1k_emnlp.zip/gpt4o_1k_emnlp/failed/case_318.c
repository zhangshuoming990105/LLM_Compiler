#include <stdio.h>

#include <stdlib.h>

#include <math.h>

int invers(int n){
    int invN = 0;
    while (n>0){
        invN = invN*10 + n%10;
        n/=10;
    }
    return invN;
}