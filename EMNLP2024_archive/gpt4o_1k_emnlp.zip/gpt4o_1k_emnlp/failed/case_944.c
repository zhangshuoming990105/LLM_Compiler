#include <stdio.h>

#include <stdlib.h>

#include <math.h>

#include <float.h>

#include <ctype.h>

#include <time.h>

#include <limits.h>

#include <string.h>

#include <stdarg.h>

double angle_diff_full(double a, double b, int sens)
{
  a -= b;
  if (sens == 1 && a<0) a+= 6.28318530718;
  if (sens == 2)
  {
    if (a>0)
      a = 6.28318530718 - a;
    else
      a = -a;
  }
  return a;
}