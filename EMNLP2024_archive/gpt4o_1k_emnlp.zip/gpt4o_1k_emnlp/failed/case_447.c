#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <stdarg.h>

#include <assert.h>

#include <stdbool.h>

#include <limits.h>

bool isBinChar(char c) {
  switch(c) {
  case 1 ... 8:
  case 11:
  case 12:
  case 14 ... 26:
  case 28 ... 31:
  case 127:
    return true;
  }
  return false;
}