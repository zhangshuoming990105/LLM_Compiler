#include <ctype.h>

char *ant_dump_num(char *dst, unsigned int ui, int base) {
    char *d = dst;
    int n = sizeof(unsigned int) * 8;
    static const char hex[] = "0123456789abcdef";

    if (base == 2) {
        while (n--)
            *dst++ = hex[(ui >> n) & 0x1];

    }else if (base == 16) {
        do {
            n -= 4;
            *dst++ = hex[(ui >> n) & 0xf];
        }while (n);

    }
    *dst = '\0';
    return d;
}