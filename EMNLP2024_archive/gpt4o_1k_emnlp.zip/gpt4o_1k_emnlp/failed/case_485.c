#include <stdio.h>

#include <string.h>

#include <ctype.h>

char codeToLetter(char code) {
 return (char) code + 'A';
}