#include <stdio.h>

#include <ctype.h>

#include <stdlib.h>

#include <stdbool.h>

int min(int num_seq[5]) {

  int min = num_seq[0];

  for (int i = 1; i < 5; i++) {
    if (num_seq[i] < min) min = num_seq[i];
  }
  return(min);
}