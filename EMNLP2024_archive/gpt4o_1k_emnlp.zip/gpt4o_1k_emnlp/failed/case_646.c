#include <stdio.h>

int iscnumber(char c)
{
 return '0' <= c && c <= '9';
}