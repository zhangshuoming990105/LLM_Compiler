#include <assert.h>

#include <stddef.h>

#include <ctype.h>

#include <stdlib.h>

#include <string.h>

#include <limits.h>

unsigned long
http_parser_version(void) {
  return 2 * 0x10000 |
         7 * 0x00100 |
         1 * 0x00001;
}