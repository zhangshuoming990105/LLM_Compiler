
double pow_by_squaring(double x, double n){

 if(n==0)return 1;
 if(n==1)return x;
 if((int)n%2==0)return pow_by_squaring(x*x, n/2);
 return x * pow_by_squaring(x*x, (n-1)/2);


}