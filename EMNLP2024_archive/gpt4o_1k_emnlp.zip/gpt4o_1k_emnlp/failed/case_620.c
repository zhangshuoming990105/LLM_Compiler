#include <stdio.h>

#include <string.h>

#include <stdbool.h>

int substr_count(char* haystack, int len, char needle) {
 int count = 0;
 for(int i = 0; i < len; i++) {
  if(haystack[i] == needle) count++;
 }
 return count;
}