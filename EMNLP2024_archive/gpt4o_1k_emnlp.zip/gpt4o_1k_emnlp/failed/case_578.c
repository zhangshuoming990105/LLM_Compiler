
int foo(int x)
{
  return __builtin_parity(x);
}