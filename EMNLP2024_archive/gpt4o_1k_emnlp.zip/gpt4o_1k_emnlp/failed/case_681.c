#include <stdio.h>		/* sprintf */

unsigned char telnet_opt_ack(unsigned char cmd)
{
 switch(cmd) {
  case 253: return 251;
  case 254: return 252;
  case 251: return 253;
  case 252: return 254;
 }
 return 0;
}