
int character(char buf[8])
{
 if(buf[0] == 27 && buf[1] >= 32 && buf[2] == 0)

  return buf[1];
 else if(buf[0] == 27 && buf[1] < 32 && buf[1] != 27 && buf[1] != 13 && buf[1] != 9 && buf[2] == 0)

  return buf[1] + 'a'-1;
 else if(buf[0] == 27 && buf[1] < 32 && buf[1] == 9 && buf[2] == 0)

  return 'i';
 else if(buf[0] == 27 && buf[1] < 32 && buf[1] == 13 && buf[2] == 0)

  return 'm';
 else if(buf[0] == 27 && buf[1] == 27 && buf[2] == 0)

  return '[';
 else if(buf[0] < 32 && buf[0] != 27 && buf[0] != 13 && buf[0] != 9 && buf[1] == 0)

  return buf[0] + 'a'-1;
 else if((buf[0] >= ' '||buf[0]==9||buf[0]==13) && buf[0] < 127)

  return buf[0];
 else

  return 0;
}