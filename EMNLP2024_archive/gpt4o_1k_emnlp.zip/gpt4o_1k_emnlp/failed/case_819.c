
int json_utf8_seq_length(unsigned char start_byte)
{
        if ((start_byte & 0x80) == 0x00) {
                return 1;
        } else if ((start_byte & 0xe0) == 0xc0) {
                return 2;
        } else if ((start_byte & 0xf0) == 0xe0) {
                return 3;
        } else if ((start_byte & 0xf8) == 0xf0) {
                return 4;
        } else {
                return (-2);
        }
}