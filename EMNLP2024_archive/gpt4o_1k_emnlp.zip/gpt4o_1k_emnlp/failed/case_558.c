
int vertice_na_solucao(int a[], int k, int vertice){
    int i;
    for(i = 0; i < k; i++){
        if(a[i] == vertice){
            return 1;
        }
    }
    return 0;
}