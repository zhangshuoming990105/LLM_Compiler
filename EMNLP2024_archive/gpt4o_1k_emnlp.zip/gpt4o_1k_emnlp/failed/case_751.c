#include <stdio.h>

int superficiedelaesfera(int r){

 int sup;

 sup = 4*3.141592654*(r*r);

 return sup;

}