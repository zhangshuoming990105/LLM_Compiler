
int gcd_s_rec(int a, int b) {
  if (a < 0) return gcd_s_rec(-a, b);
  if (b < 0) return gcd_s_rec(a, -b);
  if (a > b) return gcd_s_rec(b, a);
  if (a == 0) return b;
  return gcd_s_rec(a, b % a);
}