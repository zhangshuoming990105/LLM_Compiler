#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <ctype.h>

char to_hex(char code) {
  static char hex[] = "0123456789abcdef";
  return hex[code & 15];
}