#include <errno.h>

#include <sys/ioctl.h>

#include <fcntl.h>

#include <unistd.h>

#include <stdlib.h>

#include <time.h>

#include <string.h>

#include <stdio.h>

#include <ncurses.h>

char lcd_hwchr(char *str, int pos)
{
 int i ;
 unsigned long int c=0 ;

 if (str==NULL) return '\0' ;

 for (i=0; str[i]!='\0' && i<pos; ) {
  if ((str[i]&'\x80')==0) i++ ;
  else {
   i++ ;
   while ((str[i]&'\xC0')=='\x80') i++ ;
  }
 }

 if ((str[i]&'\x80')==0) return str[i] ;

 if ((str[i]&'\xE0')=='\xC0') {
  c|=(str[i]&'\x1F') ;
  if (str[i+1]!='\0') { c<<=5 ; c|=str[i+1]&'\x3F' ; }
 }

 if ((str[i]&'\xF0')=='\xE0') {
  c|=(str[i]&'\x0F') ;
  if (str[i+1]!='\0') { c<<=4 ; c|=str[i+1]&'\x3F' ; }
  if (str[i+2]!='\0') { c<<=6 ; c|=str[i+2]&'\x3F' ; }
 }

 if ((str[i]&'\xF8')=='\xF0') {
  c|=(str[i]&'\x07') ;
  if (str[i+1]!='\0') { c<<=3 ; c|=str[i+1]&'\x3F' ; }
  if (str[i+2]!='\0') { c<<=6 ; c|=str[i+2]&'\x3F' ; }
  if (str[i+3]!='\0') { c<<=6 ; c|=str[i+3]&'\x3F' ; }
 }

 switch(c) {
 case 0xE000: return 'E' ;
 case 0xE001: return 'N' ;
 case 0xE002: return 'D' ;
 case 0xE003: return 'E' ;
 case 0xE004: return 'N' ;
 case 0xE005: return 'D' ;
 case 0xE006: return 'V' ;
 case 0xE007: return 'v' ;
 case 0xE008: return '<' ;
 case 0xE009: return '>' ;
 case 0xE00A: return 'p' ;
 case 0xE00B: return 'b' ;
 case 0xE00C: return 'f' ;
 case 0xE00D: return 'r' ;
 case 0xE00E: return 's' ;
 case 0xE00F: return 'x' ;
 default: return '?' ;
 }
}