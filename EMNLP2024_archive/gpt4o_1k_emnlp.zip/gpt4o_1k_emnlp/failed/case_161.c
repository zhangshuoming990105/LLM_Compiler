
unsigned int
f89 (unsigned int x, unsigned int y)
{
  return (x << (8 * sizeof (unsigned int) - y)) + (x >> y);
}