#include <ctype.h>

#include <stdio.h>

#include <stdlib.h>

#include <unistd.h>

int readc_utf8(int fd, int *res)
{
    unsigned int n = 0;
    int expect = 1;

    while (expect--) {
        unsigned char ch;
        int len;

        if ((len = read(fd, &ch, 1)) == 0) {
            *res = EOF;
            return 1;
        }

        if (len == -1)
            return 0;

        if ((ch & 0b11111100) == 0b11111100) {
            n = ch & 0b00000001;
            expect = 5;
        }
        else if ((ch & 0b11111000) == 0b11111000) {
            n = ch & 0b00000011;
            expect = 4;
        }
        else if ((ch & 0b11110000) == 0b11110000) {
            n = ch & 0b00000111;
            expect = 3;
        }
        else if ((ch & 0b11100000) == 0b11100000) {
            n = ch & 0b00001111;
            expect = 2;
        }
        else if ((ch & 0b11000000) == 0b11000000) {
            n = ch & 0b00011111;
            expect = 1;
        }
        else if ((ch & 0b10000000) == 0b10000000) {
            n <<= 6;
            n |= ch & 0b00111111;
        }
        else {
            n = ch;
        }
    }

    *res = (int)n;
    return 1;
}