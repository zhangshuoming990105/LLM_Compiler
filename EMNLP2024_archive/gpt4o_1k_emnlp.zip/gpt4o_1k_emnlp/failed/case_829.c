#include <stdio.h>

float third(float gallon, int size)
{
 return gallon * size;
}