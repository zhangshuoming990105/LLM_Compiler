#include <stdlib.h>

int printArray(int arr[], int n)
{
    int i=1;
    while(arr[i]==arr[0])
    {
        i++;
    }
    return i;
}