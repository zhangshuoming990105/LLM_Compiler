#include <stdlib.h>

#include <stdio.h>

int triple_is_okay(char row1, char row2, char row3, int even) {
   if(even) {





      return ((row1 == 0x03) && (row2 == 0x0B) && ((row3 & 0x1C) == 0x0C)) ||
            ((row1 == 0x01) && (row2 == 0x05) && (row3 == 0x06)) ||
            ((row1 == 0x19) && (row2 == 0x11)) ||
            ((row1 == 0x15) && (row2 == 0x11));
   } else {





      return ((row1 == 0x13) && (row2 == 0x11)) ||
            ((row1 == 0x15) && (row2 == 0x11));
   }
}