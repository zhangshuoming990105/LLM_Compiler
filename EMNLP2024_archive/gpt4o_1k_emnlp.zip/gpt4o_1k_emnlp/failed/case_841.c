
double dbl_test (double a, double b, double c, double d)
{
  return (a > b) ? c : d;
}