#include <inttypes.h>

#include <math.h>

#include <time.h>

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <sys/time.h>

unsigned long Soma(int n)
{
    long r = 0;
    for (int i = 1; i <= n; i++)
    {
        r += i;
    }
    return r;
}