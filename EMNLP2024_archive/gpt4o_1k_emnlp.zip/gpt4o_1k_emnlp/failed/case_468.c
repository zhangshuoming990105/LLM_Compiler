#include <stdio.h>

#include <stdlib.h>

#include <assert.h>

int dayOfWeek (int doomsday, int leapYear, int month, int day) {
 int dayOfWeek = 0;
 int dateOfDoomsday = 0;

 if (month == 1 && leapYear == 1) {
   dateOfDoomsday=4;
 }else if (month == 1 && leapYear == 0) {
   dateOfDoomsday=3;
 }else if (month == 2 && leapYear == 1) {
   dateOfDoomsday=29;
 }else if (month == 2 && leapYear == 0) {
   dateOfDoomsday=28;
 }else if (month == 3) {
   dateOfDoomsday=7;
 }else if (month == 4) {
   dateOfDoomsday=4;
 }else if (month == 5) {
   dateOfDoomsday=2;
 }else if (month == 6) {
   dateOfDoomsday=6;
 }else if (month == 7) {
   dateOfDoomsday=4;
 }else if (month == 8) {
   dateOfDoomsday=8;
 }else if (month == 9) {
   dateOfDoomsday=5;
 }else if (month == 10) {
   dateOfDoomsday=3;
 }else if (month == 11) {
   dateOfDoomsday=7;
 }else if (month == 12) {
   dateOfDoomsday=5;
 }
 dayOfWeek = doomsday;
 if (day <dateOfDoomsday) {
  dayOfWeek = (((doomsday - (dateOfDoomsday-day))+42)% 7);
 } else if (day > dateOfDoomsday) {
   dayOfWeek = (((doomsday + (day-dateOfDoomsday))+42)% 7);
 }
   return (dayOfWeek);
}