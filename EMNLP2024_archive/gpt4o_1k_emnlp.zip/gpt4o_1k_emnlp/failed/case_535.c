#include <stdlib.h>

char *erase_tab(char *str)
{
  int i;

  i = 0;
  while (str[i])
    {
      if (str[i] == '\t')
 str[i] = ' ';
      i++;
    }
  return (str);
}