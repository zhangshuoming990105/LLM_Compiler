#include <stdio.h>

#include <string.h>

int params__is_list_delim_char(char c)
{
 return (c == ',');
}