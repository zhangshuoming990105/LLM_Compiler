
int
alaw2linear(
            unsigned char a_val)
{
 int t;
 int seg;

 a_val ^= 0x55;

 t = (a_val & (0xf)) << 4;
 seg = ((unsigned)a_val & (0x70)) >> (4);
 switch (seg) {
        case 0:
            t += 8;
            break;
        case 1:
            t += 0x108;
            break;
        default:
            t += 0x108;
            t <<= seg - 1;
 }
 return ((a_val & (0x80)) ? t : -t);
}