#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <math.h>

#include <ctype.h>

#include <sys/time.h>

double dpoly(double x)
{

 double a=3.0, b=1.0, c=-5.0;
 return c+ x*(2 * b + x * 3 * a);

}