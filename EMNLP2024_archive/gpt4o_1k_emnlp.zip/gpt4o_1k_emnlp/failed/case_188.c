#include <stdlib.h>

#include <stdio.h>

#include <string.h>

#include <stdarg.h>

#include <syslog.h>

#include <ctype.h>

#include <iconv.h>

#include <errno.h>

char prch(char ch) {
    if ((unsigned char) ch >= ' ')
        return ch;
    return '.';
}