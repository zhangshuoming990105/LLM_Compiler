
















int ILibBase64EncodeLength(const int inputLen)
{
 return ((inputLen * 4) / 3) + 5;
}