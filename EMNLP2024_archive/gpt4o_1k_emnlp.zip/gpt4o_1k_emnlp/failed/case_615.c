
int compareString(char inpStr[], char cmpStr[], int no)
{
 int localCtr = 0;



 for (localCtr = 0; localCtr < no; localCtr++)
 {
  if (inpStr[localCtr] != cmpStr[localCtr])
   return 1;
 }
 return 0;
}