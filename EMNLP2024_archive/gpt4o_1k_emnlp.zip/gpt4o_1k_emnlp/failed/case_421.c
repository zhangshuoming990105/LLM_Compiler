














int nulls(char *buffer, int bufsize)
{
 int i;

 char c = buffer[bufsize - 1];

 for (i = 16 * 4; i > 0; i--)
  if (buffer[bufsize - i] != c)
   return 0;
# 202 "/scratch/repos/new/home/jordi_armengol_estape/c-scraper/outputs/2022-01-22/02-19-57/repos/scs/uclinux/refs/heads/master/user/dagrab/dagrab.c"
 return 1;
}