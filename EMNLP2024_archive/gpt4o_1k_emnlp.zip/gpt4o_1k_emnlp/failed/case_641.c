#include <stdio.h>     //printf, file, getline

#include <pthread.h>   //multithreading

#include <unistd.h>

#include <sys/types.h> //types

#include <stdlib.h>    

#include <semaphore.h> //sem_wait, sem_post, sem_t

#include <string.h>    //strtok

#include <stdbool.h>   //bool, true, false

#include <time.h>      //clock_t

bool isCorrect(int board[][9]) {
 int r, c;
 int validsum = 0, sum = 0;
 for(r=1; r <= 9; r++){
  validsum += r;
 }
 for(r=0; r < 9; r++){
  sum = 0;
  for(c=0; c < 9; c++){
   sum += board[r][c];
  }
  if(sum != validsum)
   return false;
 }
 return true;
}