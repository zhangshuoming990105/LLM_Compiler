#include <stdio.h>

#include <string.h>

int is_eq(char a, char b) {
 return a == b;
}