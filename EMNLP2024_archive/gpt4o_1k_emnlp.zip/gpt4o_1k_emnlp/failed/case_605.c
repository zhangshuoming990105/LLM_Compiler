
float absFloat(float f) {
    if(f < 0)
        return -1.0 * f;
    return f;
}