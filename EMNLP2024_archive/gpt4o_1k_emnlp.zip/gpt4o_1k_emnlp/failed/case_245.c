#include <math.h>

double surface_gravity(double mass, double radius)
{
 return 6.67408E-11 * (mass / (radius * radius));
}