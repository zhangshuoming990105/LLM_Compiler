#include <string.h>

#include <stdlib.h>

#include <iconv.h>

int is_utf_special_byte(unsigned char c){
 unsigned special_byte = 0X02;
 if(c>>6==special_byte)
  return 1;
 else
  return 0;
}