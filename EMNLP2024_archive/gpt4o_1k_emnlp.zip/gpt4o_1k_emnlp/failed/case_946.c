#include <stdio.h>

#include <string.h>

int convertCharacterToInt32(char digit) {

    return digit - 48;

}