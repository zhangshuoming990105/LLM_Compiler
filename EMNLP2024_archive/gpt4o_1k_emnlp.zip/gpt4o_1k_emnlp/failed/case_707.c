
int isempty(int x[3][3])
{ int i,j;
  for(i=0;i<3;i++)
   for(j=0;j<3;j++)
  if(x[i][j]!=0)
    return 0;
   return 1;
}