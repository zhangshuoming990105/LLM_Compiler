
int diff(char a, int b) {
    putchar(98);
    if (a > b) return a - b;
    else return 1 + diff(b, a);
}