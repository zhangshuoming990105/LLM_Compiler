#include <stdlib.h>

#include <stdio.h>

#include <math.h>

double campoz(double dx, double By){
    return 3;
}