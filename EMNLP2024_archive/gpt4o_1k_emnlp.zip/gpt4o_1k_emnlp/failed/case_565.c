#include <stdio.h>

int is_right_breakable(int maze[25][25], int i, int j){
    int check = 0;
    if (j == 25 - 1){
        check = 0;
    }
    else if (maze[i][j] != maze[i][j + 1]){
        check = 1;
    }
    return check;
}