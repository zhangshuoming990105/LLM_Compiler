#include <stdlib.h>

#include <string.h>

void* MQTTPacket_header_only(unsigned char aHeader, char* data, int datalen)
{
 static unsigned char header = 0;
 header = aHeader;
 return &header;
}