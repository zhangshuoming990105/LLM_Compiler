
unsigned char padding(void)
{
  return 0xff;
}