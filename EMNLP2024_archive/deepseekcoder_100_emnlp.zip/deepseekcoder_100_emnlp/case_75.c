
int
test_01 (volatile short* x)
{
  return *x;
}