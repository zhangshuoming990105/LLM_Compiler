
int _isatty(int fd)
{
  (void)fd;
  return (1);
}