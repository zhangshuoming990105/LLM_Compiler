
int gsl_TouchNear(void)
{
  return 0;
}