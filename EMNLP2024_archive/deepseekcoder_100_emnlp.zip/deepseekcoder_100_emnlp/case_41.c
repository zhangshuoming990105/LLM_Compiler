
int
g(int a)
{
 return a;
}