#include <math.h>

#include <stddef.h>

double opTimes(double lhs, double rhs) { return lhs * rhs; }