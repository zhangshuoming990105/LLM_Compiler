
int
COLORS()
{

    return 256;
}