#include <string.h>

int vout_finish(void)
{
  return 0;
}