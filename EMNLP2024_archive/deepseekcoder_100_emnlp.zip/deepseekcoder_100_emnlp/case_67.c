#include <stdio.h>

#include <string.h>

#include <sys/types.h>

#include <sys/stat.h>

#include <signal.h>

#include <fcntl.h>

#include <unistd.h>

#include <stdlib.h>

#include <sys/wait.h>

int stop_process(int pid)
{
 return kill(pid, 15);
}