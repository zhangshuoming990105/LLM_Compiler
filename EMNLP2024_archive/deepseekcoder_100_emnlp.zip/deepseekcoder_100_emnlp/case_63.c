#include <string.h>

char* langRomTypeMicrosolFdc() { return "Microsol Disk Controller"; }